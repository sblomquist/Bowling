﻿using System.Web.UI;

namespace BowlingScoreTest.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}